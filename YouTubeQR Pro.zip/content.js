let qrSidebarTimeout = null;
let qrScanEnabled = true; // по умолчанию включено

// Проверяем состояние из Chrome storage
function updateScanState() {
  if (typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.get(['qrScanEnabled'], function(result) {
      qrScanEnabled = result.qrScanEnabled !== false;
    });
  }
}
updateScanState();

if (typeof chrome !== "undefined" && chrome.storage) {
  chrome.storage.onChanged.addListener(function(changes, areaName) {
    if (areaName === 'local' && 'qrScanEnabled' in changes) {
      qrScanEnabled = changes.qrScanEnabled !== false;
    }
  });
}

function createSidebar(link) {
  let sidebar = document.getElementById('qr-sidebar');
  if (!sidebar) {
    sidebar = document.createElement('div');
    sidebar.id = 'qr-sidebar';
    sidebar.innerHTML = `
      <style>
        #qr-sidebar { position: fixed; top: 60px; right: 0; width: 330px; background: #fff; border-left: 1px solid #ccc; box-shadow: -2px 0 8px rgba(0,0,0,0.09); z-index: 99999; font-family: Arial,sans-serif; padding: 18px 16px 16px 16px; }
        #qr-sidebar h2 { margin-top: 0; font-size: 19px; }
        #qr-sidebar .qr-link { word-break: break-all; padding: 12px 0; color: #1976D2; text-decoration: underline; cursor: pointer; display: block; font-size: 22px; font-weight: 600;}
        #qr-sidebar .close-btn { position: absolute; top: 8px; right: 10px; background: #eee; border: none; border-radius: 4px; cursor: pointer; font-size: 18px; width: 28px; height: 28px;}
      </style>
      <button class="close-btn" title="Закрыть">&times;</button>
      <h2>QR-код YouTube</h2>
      <div class="links"></div>
    `;
    document.body.appendChild(sidebar);
    sidebar.querySelector('.close-btn').onclick = () => { hideSidebar(); };
  }
  const linksDiv = sidebar.querySelector('.links');
  linksDiv.innerHTML = `<a class="qr-link" href="${link}" target="_blank">${link}</a>`;
  showSidebar();
}

function showSidebar() {
  const sidebar = document.getElementById('qr-sidebar');
  if (sidebar) {
    sidebar.style.display = "block";
    if (qrSidebarTimeout) clearTimeout(qrSidebarTimeout);
    qrSidebarTimeout = setTimeout(() => { hideSidebar(); }, 7000);
  }
}

function hideSidebar() {
  const sidebar = document.getElementById('qr-sidebar');
  if (sidebar) sidebar.style.display = "none";
  if (qrSidebarTimeout) {
    clearTimeout(qrSidebarTimeout);
    qrSidebarTimeout = null;
  }
}

function scanVideoForQR() {
  if (!qrScanEnabled) return;
  const video = document.querySelector('video');
  if (!video || video.readyState < 2) return;
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const code = jsQR(imageData.data, imageData.width, imageData.height);
  if (code && code.data && /^https?:\/\//i.test(code.data)) {
    if (window._lastQrData !== code.data) {
      createSidebar(code.data);
      window._lastQrData = code.data;
    } else {
      const sidebar = document.getElementById('qr-sidebar');
      if (sidebar && sidebar.style.display === "none") {
        createSidebar(code.data);
      }
    }
  }
}

function startQRScanLoop() {
  window._lastQrData = null;
  setInterval(scanVideoForQR, 2500);
}

function observeUrlChange(callback) {
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      callback();
    }
  }).observe(document, {subtree: true, childList: true});
}

(function() {
  startQRScanLoop();
  observeUrlChange(() => {
    window._lastQrData = null;
    hideSidebar();
  });
})();