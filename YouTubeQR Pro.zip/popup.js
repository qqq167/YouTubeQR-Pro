document.addEventListener('DOMContentLoaded', function () {
  const checkbox = document.getElementById('toggleScan');
  const status = document.getElementById('status');
  const btn = document.getElementById('scanFrameBtn');
  const manualStatus = document.getElementById('manualStatus');

  // Получаем состояние автосканирования
  chrome.storage.local.get(['qrScanEnabled'], function(result) {
    const enabled = result.qrScanEnabled !== false;
    checkbox.checked = enabled;
    status.textContent = enabled ? "Cканирование активно" : "Cканирование выключено";
    btn.disabled = enabled; // Вручную сканировать можно только если автоскан отключен
  });

  checkbox.addEventListener('change', function () {
    const enabled = checkbox.checked;
    chrome.storage.local.set({ qrScanEnabled: enabled }, function() {
      status.textContent = enabled ? "Cканирование активно" : "Cканирование выключено";
      btn.disabled = enabled;
      manualStatus.textContent = "";
    });
  });

  // Сканировать кадр вручную
  btn.addEventListener('click', function () {
    manualStatus.textContent = "Сканирование...";
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        func: () => {
          // Эта функция будет выполнена на странице YouTube
          function scanManualFrame() {
            const video = document.querySelector('video');
            if (!video || video.readyState < 2) return "Видео не найдено или не готово";
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            if (typeof jsQR !== "function") return "jsQR не загружен";
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            if (code && code.data && /^https?:\/\//i.test(code.data)) {
              // Имитация вызова createSidebar, чтобы показать QR
              if (!window._lastQrData || window._lastQrData !== code.data) {
                window._lastQrData = code.data;
              }
              let sidebar = document.getElementById('qr-sidebar');
              if (!sidebar) {
                sidebar = document.createElement('div');
                sidebar.id = 'qr-sidebar';
                sidebar.innerHTML = `
                  <style>
                    #qr-sidebar { position: fixed; top: 60px; right: 0; width: 330px; background: #fff; border-left: 1px solid #ccc; box-shadow: -2px 0 8px rgba(0,0,0,0.09); z-index: 99999; font-family: Arial,sans-serif; padding: 18px 16px 16px 16px; }
                    #qr-sidebar h2 { margin-top: 0; font-size: 19px; }
                    #qr-sidebar .qr-link { word-break: break-all; padding: 12px 0; color: #1976D2; text-decoration: underline; cursor: pointer; display: block; font-size: 22px; font-weight: 600;}
                    #qr-sidebar .close-btn { position: absolute; top: 8px; right: 10px; background: #eee; border: none; border-radius: 4px; cursor: pointer; font-size: 18px; width: 28px; height: 28px;}
                  </style>
                  <button class="close-btn" title="Закрыть">&times;</button>
                  <h2>QR-код YouTube</h2>
                  <div class="links"></div>
                `;
                document.body.appendChild(sidebar);
                sidebar.querySelector('.close-btn').onclick = () => { sidebar.style.display = "none"; };
              }
              const linksDiv = sidebar.querySelector('.links');
              linksDiv.innerHTML = `<a class="qr-link" href="${code.data}" target="_blank">${code.data}</a>`;
              sidebar.style.display = "block";
              // Автоматически скрыть через 7 секунд
              if (window.manualQRSidebarTimeout) clearTimeout(window.manualQRSidebarTimeout);
              window.manualQRSidebarTimeout = setTimeout(() => {
                sidebar.style.display = "none";
              }, 7000);
              return "QR-код найден: " + code.data;
            } else {
              return "QR-код не найден на этом кадре.";
            }
          }
          return scanManualFrame();
        }
      }, (results) => {
        if (chrome.runtime.lastError) {
          manualStatus.textContent = "Ошибка: " + chrome.runtime.lastError.message;
        } else {
          manualStatus.textContent = results && results[0] && results[0].result ? results[0].result : "Нет результата";
        }
      });
    });
  });
});